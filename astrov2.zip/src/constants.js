const Role = {
  ADMIN: "admin",
  USER: "user",
  ASTROLOGER: "astrologer",
}

module.exports = Role
