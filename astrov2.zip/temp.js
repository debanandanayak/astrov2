const client = require("./database/client")
const moment = require('moment')
const Prokerela = require("./src/services/Prokerela")
const f = async ()=>{
    const data = await client.userAstrologer.create({
        data:{
            astrologer_id:10,
            user_id:10
        }
    })
    console.log(data);
}
f()

